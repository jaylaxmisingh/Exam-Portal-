package com.exam.controller;

import com.exam.Service.Category_Service;
import com.exam.entity.exam.Category;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/category")
@CrossOrigin("*")

public class CategoryController {

    @Autowired
    private Category_Service category_service;

    // add category.
    @PostMapping("/")
    public ResponseEntity<Category> addCategory(@RequestBody Category category){
        Category category1 = this.category_service.addCategory(category);
        return ResponseEntity.ok(category1);
    }

    // get category
    @GetMapping("/{categoryId}")
    public Category getCategory(@PathVariable("categoryId") Long categoryId){
      return this.category_service.getCategory(categoryId);
    }

    // get All Categories.
    @GetMapping("/")
    public ResponseEntity<?> getCategories(){
        return ResponseEntity.ok(this.category_service.getCategories());
    }

    // update category.
    @PutMapping("/")
    public Category updateCategory(@RequestBody Category category){
      return this.category_service.updateCategory(category);
    }

    // delete category.
    @DeleteMapping("/{categoryId}")
    public void deleteCategory(@PathVariable("categoryId") long categoryId){
       this.category_service.deleteCategory(categoryId);
    }
}
