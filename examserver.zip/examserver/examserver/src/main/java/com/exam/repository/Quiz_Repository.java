package com.exam.repository;

import com.exam.entity.exam.Quiz;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Quiz_Repository extends JpaRepository<Quiz , Long > {

}
