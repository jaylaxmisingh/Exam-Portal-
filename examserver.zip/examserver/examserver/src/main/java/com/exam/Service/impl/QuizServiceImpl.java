package com.exam.Service.impl;

import com.exam.Service.Quiz_Service;
import com.exam.entity.exam.Quiz;
import com.exam.repository.Quiz_Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

@Service

public class QuizServiceImpl implements Quiz_Service {

    @Autowired
    private Quiz_Repository quiz_repository;

    @Override
    public Quiz addQuiz(Quiz quiz) {
        return this.quiz_repository.save(quiz);
    }

    @Override
    public Quiz updateQuiz(Quiz quiz) {
        return this.quiz_repository.save(quiz);
    }

    @Override
    public Set<Quiz> getQuizzes() {
        return new HashSet<>(this.quiz_repository.findAll());
    }

    @Override
    public Quiz getQuiz(long quizId) {
        return this.quiz_repository.findById(quizId).get();
    }

    @Override
    public void deleteQuiz(long quizId) {

        Quiz quiz = new Quiz();
        quiz.setqId(quizId);
        this.quiz_repository.delete(quiz);
    }
}
