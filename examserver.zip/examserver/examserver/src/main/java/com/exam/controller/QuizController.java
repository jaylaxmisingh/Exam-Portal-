package com.exam.controller;

import com.exam.Service.Quiz_Service;
import com.exam.entity.exam.Quiz;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin("*")
@RequestMapping("/quiz")
public class QuizController {

    @Autowired
    private Quiz_Service quiz_service;

    // add quiz service
    @PostMapping("/")
    public ResponseEntity<Quiz> addQuiz(@RequestBody Quiz quiz) {
        return ResponseEntity.ok(this.quiz_service.addQuiz(quiz));
    }

    // update method.
    @PutMapping("/")
    public ResponseEntity<Quiz> updateQuiz(@RequestBody Quiz quiz) {
        return ResponseEntity.ok(this.quiz_service.updateQuiz(quiz));
    }

    // get quizzes
    @GetMapping("/")
    public ResponseEntity<?> getQuizzes() {
        return ResponseEntity.ok(this.quiz_service.getQuizzes());
    }

    // get quiz
    @GetMapping("/{qid}")
    public Quiz quiz(@PathVariable("qid") long qid) {
        return this.quiz_service.getQuiz(qid);
    }

    // delete quiz
    @DeleteMapping("/{qid}")
    public void delete(@PathVariable("qid") long qid) {
        this.quiz_service.deleteQuiz(qid);
    }
}
