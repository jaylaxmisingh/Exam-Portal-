package com.exam.Service;

import com.exam.entity.exam.Quiz;

import java.util.Set;

public interface Quiz_Service {

    public Quiz addQuiz(Quiz quiz);

    public Quiz updateQuiz(Quiz quiz);

    public Set<Quiz> getQuizzes();

    public Quiz getQuiz(long quizId);

    public void deleteQuiz(long quizId);
}
