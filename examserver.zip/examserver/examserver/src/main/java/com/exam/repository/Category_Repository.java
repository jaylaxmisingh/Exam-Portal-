package com.exam.repository;

import com.exam.entity.exam.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Category_Repository extends JpaRepository<Category , Long> {

}
