package com.exam.Service.impl;

import com.exam.Service.Category_Service;
import com.exam.entity.exam.Category;
import com.exam.repository.Category_Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.LinkedHashSet;
import java.util.Set;

@Service
public class CategoryServiceImpl implements Category_Service {

    @Autowired
    private Category_Repository category_repository;

    @Override
    public Category addCategory(Category category) {
        return this.category_repository.save(category);
    }

    @Override
    public Category updateCategory(Category category) {
        return this.category_repository.save(category);
    }

    @Override
    public Set<Category> getCategories() {
        return new LinkedHashSet<>(this.category_repository.findAll());
    }

    @Override
    public Category getCategory(long categoryId) {
        return category_repository.findById(categoryId).get();
    }

    @Override
    public void deleteCategory(long categoryId) {
        Category  category = new Category();
        category.setCid(categoryId);
        this.category_repository.delete(category);
    }
}
