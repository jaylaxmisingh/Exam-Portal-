package com.exam.Service;

import com.exam.entity.exam.Category;

import java.util.Set;

public interface Category_Service {
    public Category addCategory(Category category);

    public Category updateCategory(Category category);

    public Set<Category> getCategories();

    public Category getCategory(long categoryId);

    public void deleteCategory(long categoryId);
}
