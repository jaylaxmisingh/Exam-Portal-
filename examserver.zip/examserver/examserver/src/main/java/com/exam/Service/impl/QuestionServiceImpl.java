package com.exam.Service.impl;

import com.exam.Service.Question_Service;
import com.exam.entity.exam.Question;
import com.exam.entity.exam.Quiz;
import com.exam.repository.Question_Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Set;

@Service

public class QuestionServiceImpl implements Question_Service {

    @Autowired
    private Question_Repository question_repository ;

    @Override
    public Question addQuestion(Question question) {
        return this.question_repository.save(question);
    }

    @Override
    public Question updateQuestion(Question question) {
        return this.question_repository.save(question);
    }

    @Override
    public Set<Question> getQuestions() {
        return new HashSet<>(this.question_repository.findAll());
    }

    @Override
    public Question getQuestion(Long questionId) {
        return this.question_repository.findById(questionId).get();
    }

    @Override
    public Set<Question> getQuestionsOfQuiz(Quiz quiz) {
        return this.question_repository.findByQuiz(quiz);
    }

    @Override
    public void deleteQuestion(long questionId) {
        Question question = new Question();
        question.setQuesId(questionId);
        this.question_repository.delete(question);
    }
}
