import {
  MatDivider,
  MatDividerModule
} from "./chunk-56I3AQ6T.js";
import "./chunk-6PIYQF62.js";
import "./chunk-ATDCE2H4.js";
import "./chunk-ZIV73OBM.js";
import "./chunk-WDMUDEB6.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
