import { Component } from '@angular/core';

@Component({
  selector: 'app-add-question',
  templateUrl: './add-question.component.html',
  styleUrl: './add-question.component.css'
})
export class AddQuestionComponent {
  quizTitle = 'Basic Angular Quiz';
  quizQuestions = [
    {
      text: 'What is the command to create a new Angular component?',
      options: ['ng generate component', 'ng create component', 'ng new component', 'ng build component'],
      correctAnswer: 'ng generate component',
    },
    {
      text: 'Which directive is used for conditional rendering?',
      options: ['*ngFor', '*ngIf', '*ngSwitch', '*ngBind'],
      correctAnswer: '*ngIf',
    },
  ];
  answers: string[] = [];
  result: number | null = null;

  submitQuiz() {
    this.result = this.quizQuestions.reduce((score, question, index) => {
      return score + (this.answers[index] === question.correctAnswer ? 1 : 0);
    }, 0);
  }
}
