import { Component, OnInit } from '@angular/core';
import { LoginuserService } from '../../services/loginuser.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent implements OnInit{
  user = null
constructor(){}

ngOnInit(): void {

// this.user = this.login.ge

}
}
