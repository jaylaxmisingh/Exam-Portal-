import { Component, OnInit } from '@angular/core';
import { base64demonSlayer } from '../../../assets/imagedata.js'
import { MatSnackBar } from '@angular/material/snack-bar';
import { UserService } from '../../services/user.service.js';
import { LoginuserService } from '../../services/loginuser.service.js';
import { T } from '@angular/cdk/keycodes';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit {
  loginData = {
    username: '',
    password: ''
  };

  constructor(private snack: MatSnackBar, private loginUserService : LoginuserService) { }


 
  ngOnInit(): void {

  }

  demonSlayerimg = base64demonSlayer;

  formSubmit() {
    console.log("form is submitted !!")
    if (this.loginData.username == null || this.loginData.username.trim() == '') {
      this.snack.open('username is required !!', '', {
        duration: 3000
      });
      return;
    }

    if (this.loginData.password == null || this.loginData.password.trim() == '') {
      this.snack.open('password is required !!', '', {
        duration: 3000
      });
      return;
    }
  }
}
