import { Component, OnInit } from '@angular/core';
import { base64demonSlayer } from '../../../assets/imagedata.js'
import { UserService } from '../../services/user.service.js';
import { MatSnackBar } from '@angular/material/snack-bar';
import Swal from 'sweetalert2'

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.css'
})
export class SignupComponent implements OnInit {
  demonSlayerimg = base64demonSlayer;

  constructor(private userService: UserService, public snack: MatSnackBar) { }

  public user = {
    username: '',
    password: '',
    firstname: '',
    lastname: '',
    email: '',
    phone: ''
  };


  ngOnInit(): void { }

  formSubmit() {
    console.log(this.user)
    if (this.user.username == '' || this.user.username == null) {
      // alert('Username is required')
      this.snack.open('Username is required !! ', '', {
        duration: 3000,
      });
      return;
    }
    if (this.user.password == '' || this.user.password == null) {
      alert('Password is required')
      return;
    }
    if (this.user.firstname == '' || this.user.firstname == null) {
      alert('firstname is required')
      return;
    }
    if (this.user.lastname == '' || this.user.lastname == null) {
      alert('Lastname is required')
      return;
    }
    if (this.user.email == '' || this.user.email == null) {
      alert('Email is required')
      return;
    }
    if (this.user.phone == '' || this.user.phone == null) {
      alert('Phone is required')
      return;
    }

    // add user : userService.
    this.userService.addUser(this.user).subscribe(
      (data: any) => {
        // success.
        console.log(data);
        // alert('success')
        Swal.fire("Sucessfully Registered !!", "User id is " +data.id, "success")
      },
      (error) => {
        // error
        console.log(error);
        // alert('something went wrong');
        this.snack.open('something went wrong!!', '', {
          duration:300,
        })
      }
    );
  }
}
