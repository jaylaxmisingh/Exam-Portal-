import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginuserService {
private baseUrl = "http://localhost:8080/login"
  constructor(private httpClient : HttpClient) { } 

  loginUser(loginUser : LoginuserService):Observable<object>{
   return this.httpClient.post(`${this.baseUrl}`,loginUser)
  }
}
